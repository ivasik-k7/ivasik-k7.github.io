# GameRuntime, second pass

Drop-in replacement. `core/types.ts` is untouched — the new surface lives in
`core/runtime-types.ts` and intersects onto your existing types, so an
unmodified `GameConfig<W>` still type-checks and behaves identically: same keys,
same sticky targeting, same idle flourishes, same handler signatures.

```
core/runtime-types.ts   additive types (RuntimeConfig, SeqStep, ActorDef, …)
core/runtime-perf.ts    Timers, GameClock, FxPool, QualityGovernor, sprite atlas, input
core/runtime-cull.tsx   BandProvider, useVisibleBand, CullBox, CullStrip
engine/GameRuntime.tsx  the component
```

## Where the performance actually came from

Ordered by how much they matter when a lot is on screen.

**1. Occlusion culling.** The loop publishes the visible world slice every frame
as `--vis-x0` / `--vis-x1` and through a quantized external store. Wrap heavy
regions and they unmount off camera, so cost tracks *screen*, not *scene*:

```tsx
import { CullBox, CullStrip } from "../core/runtime-cull";

<CullBox x={1200} width={400}><MarketStalls /></CullBox>

<CullStrip width={def.width} chunkWidth={320} render={({ x, width }) => (
  <Cobblestones x={x} width={width} />
)} />
```

The store is quantized to 32 logical px, so a settled camera notifies nobody.

**2. `def.artKey`.** Previously *any* world write re-rendered hundreds of rects,
because the art memo keyed on world identity. Give the scene a fingerprint of
what its art actually reads and unrelated world writes stop touching it:

```ts
artKey: (world, phase) => `${phase}|${world.lampsLit}|${world.doorOpen ? 1 : 0}`
```

**3. Sprite atlas.** `spriteMode: "auto"` bakes every player frame into one
offscreen canvas and renders the character as a single `<canvas>` — one
`drawImage` per frame change instead of hundreds of live SVG rects. It falls
back to the DOM path automatically if the pixel-map shape isn't recognised, and
`"dom"` forces the old behaviour. Unused frames also mount lazily now, with the
rest prewarmed on the first idle callback.

**4. The loop parks.** Hidden tab or scrolled-out viewport → `cancelAnimationFrame`
and held keys released. Behind a dialogue or overlay it throttles to `pausedHz`
(24 by default) since only the idle breath is animating. Input, fx and toasts
wake it.

**5. Fixed-step simulation.** A 120 Hz accumulator with a bounded substep count
means walking covers the same ground at 30 fps and 165 fps, and a stall drops
its backlog instead of teleporting the player.

**6. Fewer per-frame writes.** `transform-origin` is only written while zoomed;
`will-change` is granted while something moves and released ~700 ms after it
settles, so idle scenes give their compositor layers back. Targeting recomputes
only when position, facing, world revision or scene changed (plus a 400 ms
safety net) instead of every frame.

**7. Pooled fx and owned timers.** Fx recycle fixed slots and expire in the
sweep, replacing one `setTimeout` per particle. Every timer the runtime opens is
tracked and disposed on unmount — travel, blackout, toasts and fx all used to
leak theirs.

## Fixed along the way

- Alt-tabbing mid-stride left the player walking forever (`blur` now releases keys).
- Unmounting during a travel fade or a queued toast fired `setState` afterwards.
- The keyboard listener and the rAF loop re-subscribed whenever any callback
  identity changed; both now mount once and read through refs.
- `playerAppearance` returning a fresh object each call re-rendered every
  `PixelSprite` on every commit; the palette is now pinned to its content.
- Autosave debounce could be lost on tab close — it flushes on `pagehide`,
  `visibilitychange` and unmount, and only writes when something is dirty.

## New capability, all opt-in

**Cutscenes.** `ctx.runSequence([...], { cinematic: true })` runs on the game
clock, respects pause, locks input, and letterboxes:

```ts
await ctx.runSequence([
  { letterbox: true },
  { focus: 240, ms: 700 },
  { walkTo: 210 },
  { face: 1 },
  { say: "The door was already open." },
  { shake: 6, ms: 400 },
  { fx: { kind: "dust", x: 240 } },
  { dialogue: innkeeperTree },
  { until: () => ctx.flag("lampLit"), timeoutMs: 5000 },
  { travel: { scene: "cellar" } },
], { cinematic: true });
```

**Point and click.** Tapping or clicking an object targets it, walks there and
uses it (`pointerPicking`, `autoWalkToTargets`; edge-holds still walk). Objects
can carry `approachX`, `width`, `hitPad`, `once`, `cooldownMs`.

**Gamepad**, polled only once one is connected. **Remappable keys** via
`config.keymap`. **Input buffering**: an interact pressed during an action fires
when the action ends instead of vanishing.

**Camera**: `ctx.focusCamera(x)`, `ctx.zoom(1.6, 600)`, `ctx.flash()`,
`ctx.letterbox(true)`, plus the existing shake.

**Flags without widening your world type**: `ctx.flag`, `setFlag`, `counter`,
`bump`, `once` — persisted alongside the save, with facing and per-scene
positions, so re-entering a room puts you back where you left.

**Actors**: `def.actors` gives patrolling or scripted background characters,
transform-cached and skipped entirely off camera.

**Adaptive quality**: frame times drive a `high|medium|low` tier with asymmetric
dwell times (drop fast, recover slowly), exposed as `--quality` on the scene
container, as `ctx.quality()`, and via `onQualityChange` — let heavy `Effects`
shed particles instead of dropping frames.

**Accessibility**: `prefers-reduced-motion` disables bob, sway, shake, look-ahead
and shortens fades; toasts announce through a live region; `def.describe` gives
screen readers the room.

**Debug HUD**: `debug: true` (toggle with F3 or `` ` ``) shows fps, EMA frame
time, sim steps, DOM writes vs skips, React commits, live fx, pending alarms and
timers, the cull band, sprite mode and JS heap. Override with `renderDebug`.

**`onReady(api)`** hands over `interact / travel / walkTo / runSequence /
getWorld / updateWorld / getStats / saveNow` for tests and tooling.

## Suggested starting config

```ts
{
  ...existingConfig,
  simHz: 120,
  pauseWhenHidden: true,
  spriteMode: "auto",
  adaptiveQuality: true,
  debug: import.meta.env.DEV,
}
```

Then add `artKey` to your busiest scene and wrap its heaviest region in
`CullBox` — that pair is most of the win.

## Two things to know

- Zoom scales the compositor layer, so non-integer values soften pixel art.
  Integer or half steps look best; `zoom(1)` restores exact crispness.
- `spriteMode: "auto"` only switches to canvas past `spriteAtlasThreshold`
  (~2400 cells). Check the debug HUD's `sprite` field to confirm which path is
  live before attributing a win to it.
